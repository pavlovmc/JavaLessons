package HomeWork_4;

public class HomeWork_4 {
    public static void main(String[] args) {
        new Chat();
    }
}
